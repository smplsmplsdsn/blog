var folder = Folder.selectDialog();
var document = app.activeDocument;
if(document && folder)
{
var options = new ExportOptionsPNG24();
options.antiAliasing = true;
options.transparency = true;
options.artBoardClipping = true;
options.verticalScale = 277.777;
options.horizontalScale = 277.777;

var n = document.layers.length;
for(var i=0; i<n; ++i)
{
hideAllLayers();
var layer = document.layers[i];
layer.visible = true;

var file = new File(folder.fsName+"/"+layer.name+".png");

document.exportFile(file,ExportType.PNG24,options);
}

showAllLayers();
}

function hideAllLayers()
{
forEach(document.layers, function(layer) {
layer.visible = false;
});
}

function showAllLayers()
{
forEach(document.layers, function(layer) {
layer.visible = true;
});
}

function forEach(collection, fn)
{
var n = collection.length;
for(var i=0; i<n; ++i)
{
fn(collection[i]);
}
}